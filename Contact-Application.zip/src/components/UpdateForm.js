import React, { useState, useEffect } from 'react'
import { Button, Checkbox, Form } from 'semantic-ui-react'
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
function UpdateForm() {
    let navigate = useNavigate();
    const [firstName, setFirstName] = useState('');
    const [email, setEmail] = useState('');
    const [ID, setID] = useState(null);
    console.log(firstName, email)



    const sendDataToApi = () => {
        axios.put(`https://647860bb362560649a2da568.mockapi.io/CRUD/${ID}`, {
            firstName,
            email
        }).then(() => {
            navigate('/read')
        })
    }

    useEffect(() => {
        setFirstName(localStorage.getItem('firstName'))
        setEmail(localStorage.getItem('email'))
        setID(localStorage.getItem('ID'))
    }, [])


    return (
        <Form>
            <Form.Field>
                <label>First Name</label>
                <input placeholder='First Name' name="fname" value={firstName} onChange={(e) => setFirstName(e.target.value)} />
            </Form.Field>
            <Form.Field>
                <label>Email</label>
                <input type="email" placeholder='Email' name="email" value={email} onChange={(e) => setEmail(e.target.value)} />
            </Form.Field>

            <Button type='submit' onClick={sendDataToApi}>Update</Button>

        </Form>
    )
}
export default UpdateForm;