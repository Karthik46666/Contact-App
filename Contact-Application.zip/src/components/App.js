import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'
import './App.css';
import LoginForm from './LoginForm';
import DisplayForm from './DisplayForm';
import UpdateForm from './UpdateForm';



function App() {

  return (
    <>
      <Router>
        <div className="main">
          <h2 className="main-header">Login</h2>
          <Routes>
            <Route exact path="/" element={<LoginForm />} />
            <Route exact path="/read" element={<DisplayForm />} />
            <Route exact path='/update' element={<UpdateForm />} />
          </Routes>
        </div>
      </Router>
    </>
  );
}

export default App;
