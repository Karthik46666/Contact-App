import React, { useState } from 'react'
import { Button, Checkbox, Form } from 'semantic-ui-react'
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
function LoginForm() {
    let navigate = useNavigate();
    const [firstName, setFirstName] = useState('');
    const [email, setEmail] = useState('');
    console.log(firstName, email)


    const sendDataToApi = () => {
        axios.post(`https://647860bb362560649a2da568.mockapi.io/CRUD`, {
            firstName,
            email
        }).then(() => {
            navigate('/read')
        })
    }

    return (
        <Form>
            <Form.Field>
                <label>First Name</label>
                <input placeholder='First Name' name="firstName" value={firstName} onChange={(e) => setFirstName(e.target.value)} />
            </Form.Field>
            <Form.Field>
                <label>Email</label>
                <input type="email" placeholder='Email' name="email" value={email} onChange={(e) => setEmail(e.target.value)} />
            </Form.Field>

            <Button type='submit' onClick={sendDataToApi}>Submit</Button>
        </Form>
    )
}
export default LoginForm;