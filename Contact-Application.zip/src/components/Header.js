function Header() {
    return (
        <nav class="navbar navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">Contact Manager</a>
            </div>
        </nav>
    )
}
export default Header
